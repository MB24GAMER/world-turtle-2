'use client';

import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import useLocalStorage from '@/hooks/use-local-storage';
import { type ShopItem } from '@/lib/types';
import { Coins } from 'lucide-react';

const shopItems: ShopItem[] = [
  { id: 'pickaxe_1', name: 'Steel Pickaxe', description: 'Increases mining speed by 10%.', price: 500, image: 'https://placehold.co/300x200.png', imageHint: 'steel pickaxe' },
  { id: 'gem_finder_1', name: 'Gem Finder', description: 'Chance to find bonus gems.', price: 1200, image: 'https://placehold.co/300x200.png', imageHint: 'glowing gem' },
  { id: 'storage_1', name: 'Bigger Bag', description: 'Increases your inventory size.', price: 800, image: 'https://placehold.co/300x200.png', imageHint: 'leather bag' },
  { id: 'luck_charm_1', name: 'Luck Charm', description: 'Slightly increases rare finds.', price: 2500, image: 'https://placehold.co/300x200.png', imageHint: 'four-leaf clover' },
];

export default function ShopPage() {
  const { toast } = useToast();
  const [coins, setCoins] = useLocalStorage('coins', 100);

  const handleBuy = (item: ShopItem) => {
    if (coins >= item.price) {
      setCoins(prev => prev - item.price);
      toast({
        title: 'Purchase Successful!',
        description: `You bought ${item.name} for ${item.price} coins.`,
      });
    } else {
      toast({
        title: 'Not enough coins!',
        description: `You need ${item.price - coins} more coins to buy ${item.name}.`,
        variant: 'destructive',
      });
    }
  };
  
  return (
    <div className="p-4 space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold font-headline">Shop</h1>
        <p className="text-muted-foreground">Spend your coins on powerful upgrades.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {shopItems.map(item => (
          <Card key={item.id} className="flex flex-col">
            <CardHeader className="p-0">
              <div className="relative h-32 w-full">
                <Image
                  src={item.image}
                  alt={item.name}
                  fill
                  sizes="(max-width: 640px) 100vw, 50vw"
                  className="object-cover rounded-t-lg"
                  data-ai-hint={item.imageHint}
                />
              </div>
            </CardHeader>
            <CardContent className="p-4 flex flex-col flex-1">
              <CardTitle className="text-lg">{item.name}</CardTitle>
              <CardDescription className="text-sm mt-1 flex-1">{item.description}</CardDescription>
              <div className="flex items-center justify-between mt-4">
                <div className="flex items-center gap-1 font-bold text-accent">
                  <Coins className="h-4 w-4" />
                  <span>{item.price.toLocaleString()}</span>
                </div>
                <Button size="sm" onClick={() => handleBuy(item)}>Buy</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
