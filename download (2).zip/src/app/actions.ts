'use server';

import { generateDailyTasks as generateDailyTasksFlow, GenerateDailyTasksInput } from '@/ai/flows/generate-daily-tasks';
import { ai } from '@/ai/genkit';
import { z } from 'zod';
import type { DailyTask } from '@/lib/types';

const generateTasksSchema = z.object({
  userActivity: z.string(),
});

export async function generateNewTasks(input: { userActivity: string }): Promise<{ error?: string; tasks?: DailyTask[] }> {
  const parsedInput = generateTasksSchema.safeParse(input);
  if (!parsedInput.success) {
    return { error: 'Invalid input.' };
  }

  try {
    const aiInput: GenerateDailyTasksInput = {
      userActivity: parsedInput.data.userActivity,
      taskPreferences: 'Keep tasks varied, related to mining, exploration, and upgrading equipment.',
    };

    const result = await generateDailyTasksFlow(aiInput);

    if (!result || !result.tasks || result.tasks.length === 0) {
      return { error: 'The AI was unable to generate new tasks. Please try again.' };
    }

    const newTasks: DailyTask[] = result.tasks.map(taskText => ({
      id: crypto.randomUUID(),
      text: taskText,
      claimed: false,
      reward: Math.floor(Math.random() * 41) + 10, // Reward between 10 and 50
    }));

    return { tasks: newTasks };
  } catch (e) {
    console.error('Error generating tasks:', e);
    return { error: 'An unexpected error occurred while generating tasks.' };
  }
}

const generateImageSchema = z.object({
    prompt: z.string(),
});

export async function generateImageAction(input: { prompt: string }): Promise<{ error?: string; imageUrl?: string }> {
    const parsedInput = generateImageSchema.safeParse(input);
    if (!parsedInput.success) {
        return { error: 'Invalid input.' };
    }

    try {
        const { output } = await ai.generate({
          model: 'googleai/gemini-2.0-flash-preview-image-generation',
          prompt: `A high-resolution, photorealistic image of a ${parsedInput.data.prompt}, gaming PC component style, on a dark background.`,
          config: {
            responseModalities: ['TEXT', 'IMAGE'],
          },
        });

        const imageUrl = output?.media?.url;

        if (!imageUrl) {
          throw new Error('Image generation failed to return a valid URL.');
        }

        return { imageUrl };
    } catch (e) {
        console.error('Error generating image:', e);
        const errorMessage = e instanceof Error ? e.message : 'An unexpected error occurred while generating the image.';
        return { error: errorMessage };
    }
}
