'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import useLocalStorage from '@/hooks/use-local-storage';
import { type MiningRig } from '@/lib/types';
import { Coins, Zap, ChevronsUp, BarChart, Plus, Loader2 } from 'lucide-react';
import { generateImageAction } from '@/app/actions';


const initialRigs: MiningRig[] = [
  {
    id: 'nano_dig',
    name: 'Nano Dig',
    level: 6,
    miningRate: 3,
    upgradeCost: 1000,
    progress: 0,
    maxProgress: 14,
    image: 'https://placehold.co/100x100.png',
    imageHint: 'silver graphics card',
    lastClaimed: Date.now(),
    accumulated: 0,
  },
  {
    id: 'micro_mine',
    name: 'Micro Mine',
    level: 6,
    miningRate: 4,
    upgradeCost: 2800,
    progress: 0,
    maxProgress: 28,
    image: 'https://placehold.co/100x100.png',
    imageHint: 'green graphics card',
    lastClaimed: Date.now(),
    accumulated: 0,
  },
  {
    id: 'mini_extractor',
    name: 'Mini Extractor',
    level: 10,
    miningRate: 6,
    upgradeCost: 5000,
    progress: 0,
    maxProgress: 99,
    image: 'https://placehold.co/100x100.png',
    imageHint: 'blue graphics card',
    lastClaimed: Date.now(),
    accumulated: 0,
  },
];

export default function HomePage() {
  const { toast } = useToast();
  const [coins, setCoins] = useLocalStorage('coins', 50000);
  const [rigs, setRigs] = useLocalStorage<MiningRig[]>('miningRigs', initialRigs);
  const [isClient, setIsClient] = useState(false);
  const [generatingImages, setGeneratingImages] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setIsClient(true);
    const interval = setInterval(() => {
      setRigs(prevRigs =>
        prevRigs.map(rig => {
          const secondsPassed = (Date.now() - rig.lastClaimed) / 1000;
          const newAccumulated = rig.accumulated + (secondsPassed * rig.miningRate) / 3600; // Assuming rate is per hour
          return { ...rig, accumulated: newAccumulated, lastClaimed: Date.now() };
        })
      );
    }, 1000);

    return () => clearInterval(interval);
  }, [setRigs]);

  useEffect(() => {
    if (isClient) {
      rigs.forEach(rig => {
        if (rig.image.startsWith('https://placehold.co')) {
          handleGenerateImage(rig.id, rig.imageHint);
        }
      });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isClient]);

  const handleGenerateImage = async (rigId: string, prompt: string) => {
    if (generatingImages[rigId]) return;
    setGeneratingImages(prev => ({...prev, [rigId]: true}));
    try {
        const result = await generateImageAction({ prompt });
        if(result.imageUrl) {
            setRigs(prevRigs => prevRigs.map(r => r.id === rigId ? { ...r, image: result.imageUrl! } : r));
        } else {
             toast({ title: 'Image generation failed', description: result.error, variant: 'destructive' });
        }
    } catch (error) {
        toast({ title: 'Image generation failed', description: error instanceof Error ? error.message : 'An unexpected error occurred.', variant: 'destructive' });
    } finally {
        setGeneratingImages(prev => ({...prev, [rigId]: false}));
    }
  };

  const handleClaim = (rigId: string) => {
    setRigs(prevRigs => {
      const rigToClaim = prevRigs.find(r => r.id === rigId);
      if (!rigToClaim || rigToClaim.accumulated < 1) return prevRigs;
      
      const claimedAmount = Math.floor(rigToClaim.accumulated);
      setCoins(prevCoins => prevCoins + claimedAmount);
      toast({
        title: 'Claimed!',
        description: `You claimed ${claimedAmount.toLocaleString()} coins.`,
      });

      return prevRigs.map(r =>
        r.id === rigId ? { ...r, accumulated: 0, lastClaimed: Date.now() } : r
      );
    });
  };

  const handleUpgrade = (rigId: string) => {
    setRigs(prevRigs => {
      const rigToUpgrade = prevRigs.find(r => r.id === rigId);
      if (!rigToUpgrade || coins < rigToUpgrade.upgradeCost) {
        toast({
          title: 'Not enough coins!',
          description: `You need ${rigToUpgrade ? (rigToUpgrade.upgradeCost - coins).toLocaleString() : 0} more coins.`,
          variant: 'destructive',
        });
        return prevRigs;
      }

      setCoins(prevCoins => prevCoins - rigToUpgrade.upgradeCost);

      return prevRigs.map(r => {
        if (r.id === rigId) {
          const newProgress = r.progress + 1;
          if (newProgress >= r.maxProgress) {
            toast({
              title: 'Level Up!',
              description: `${r.name} has been leveled up!`,
            });
            return {
              ...r,
              level: r.level + 1,
              progress: 0,
              miningRate: r.miningRate * 1.2,
              upgradeCost: Math.floor(r.upgradeCost * 1.5),
            };
          }
          return { ...r, progress: newProgress };
        }
        return r;
      });
    });
  };

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return Math.floor(num);
  };

  if (!isClient) {
    return null;
  }

  return (
    <div className="p-4 space-y-4">
      <Card className="text-center bg-card/50">
        <CardContent className="p-4">
          <p className="flex items-center justify-center gap-2 text-muted-foreground">
            <Coins className="h-5 w-5 text-primary" /> Your Balance
          </p>
          <p className="text-4xl font-bold text-foreground">
            {coins.toLocaleString()}
          </p>
        </CardContent>
      </Card>
      
      <div className="space-y-4">
        {rigs.map(rig => (
          <Card key={rig.id} className="bg-card/80 p-4">
            <div className="grid grid-cols-[80px_1fr] gap-4 items-center">
              <div className="flex flex-col items-center gap-2">
                <div className="w-[80px] h-[80px] rounded-md bg-secondary flex items-center justify-center">
                 {generatingImages[rig.id] ? (
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  ) : (
                    <Image src={rig.image} alt={rig.name} width={80} height={80} data-ai-hint={rig.imageHint} className="rounded-md" />
                  )}
                </div>
                 <div className="flex items-center gap-2">
                   <Button variant="destructive" size="icon" className="h-6 w-6">
                    <Plus className="h-4 w-4" />
                   </Button>
                   <span className="text-xs font-bold text-muted-foreground">0%</span>
                 </div>
              </div>
              <div className="space-y-2">
                <div className='flex justify-between items-start'>
                  <div>
                    <h3 className="font-bold text-lg">{rig.name}</h3>
                    <p className="text-sm text-muted-foreground flex items-center gap-1"><Zap className="h-4 w-4" /> {rig.miningRate}/s</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <BarChart className="h-4 w-4 text-primary" />
                    <span className="text-sm font-bold">lvl {rig.level}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Progress value={(rig.progress / rig.maxProgress) * 100} className="w-full h-4" />
                  <span className="text-xs font-mono text-muted-foreground">{rig.progress}/{rig.maxProgress}</span>
                </div>
                
                <div className="flex items-center gap-2">
                   <Button onClick={() => handleUpgrade(rig.id)} className="w-full bg-primary text-primary-foreground font-bold" disabled={coins < rig.upgradeCost}>
                    UPGRADE
                  </Button>
                  <Button variant="destructive" className="w-full bg-accent text-accent-foreground font-bold" onClick={() => handleClaim(rig.id)}>
                    CLAIM {formatNumber(rig.accumulated)} <Coins className="ml-1 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
