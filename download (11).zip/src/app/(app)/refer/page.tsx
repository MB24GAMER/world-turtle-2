'use client';

import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import useLocalStorage from '@/hooks/use-local-storage';
import { Copy, Users, Award, Share2 } from 'lucide-react';

export default function ReferPage() {
  const { toast } = useToast();
  const [referralCode, setReferralCode] = useLocalStorage('referralCode', '');
  const [invitedFriendsCount, setInvitedFriendsCount] = useLocalStorage('invitedFriendsCount', 5);
  const [rewardsEarned, setRewardsEarned] = useLocalStorage('rewardsEarned', 1250);
  const [isClient, setIsClient] = useState(false);
  const [telegramBotUsername] = useLocalStorage('telegramBotUsername', 'elyra_mining_bot'); // Replace with your bot's username

  useEffect(() => {
    setIsClient(true);
    if (isClient && !referralCode) {
      const newCode = `ELYRA-${Math.random()
        .toString(36)
        .substring(2, 8)
        .toUpperCase()}`;
      setReferralCode(newCode);
    }
  }, [isClient, referralCode, setReferralCode]);

  const referralLink = `https://t.me/${telegramBotUsername}?start=${referralCode}`;

  const handleCopy = () => {
    if (!referralCode) return;
    navigator.clipboard.writeText(referralLink);
    toast({
      title: 'Copied!',
      description: 'Referral link copied to clipboard.',
    });
  };

  const handleInvite = () => {
    if (typeof window === 'undefined' || !referralCode) return;

    const text = `Join me on Elyra Mining! Use my referral link to get a bonus! ${referralLink}`;
    
    const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent(text)}`;
    
    window.open(telegramUrl, '_blank');
  };

  if (!isClient) {
    return null; // Or a loading skeleton
  }

  return (
    <div className="p-4 space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold font-headline">Refer & Earn</h1>
        <p className="text-muted-foreground">
          Invite friends and earn rewards together!
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Referral Link</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-3 bg-secondary rounded-lg">
            <span className="font-mono text-lg overflow-x-auto no-scrollbar">{referralLink}</span>
            <Button size="icon" variant="ghost" onClick={handleCopy}>
              <Copy className="h-5 w-5" />
            </Button>
          </div>
          <Button className="w-full mt-4" size="lg" onClick={handleInvite}>
            <Share2 className="mr-2 h-5 w-5" />
            Invite Friends
          </Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-4">
        <Card className="text-center">
          <CardHeader>
            <div className="flex justify-center mb-2">
              <div className="p-3 bg-primary/20 rounded-full">
                <Users className="h-6 w-6 text-primary" />
              </div>
            </div>
            <CardTitle>{invitedFriendsCount}</CardTitle>
            <CardDescription>Friends Invited</CardDescription>
          </CardHeader>
        </Card>
        <Card className="text-center">
          <CardHeader>
            <div className="flex justify-center mb-2">
              <div className="p-3 bg-accent/20 rounded-full">
                <Award className="h-6 w-6 text-accent" />
              </div>
            </div>
            <CardTitle>{rewardsEarned.toLocaleString()}</CardTitle>
            <CardDescription>Rewards Earned</CardDescription>
          </CardHeader>
        </Card>
      </div>
    </div>
  );
}
