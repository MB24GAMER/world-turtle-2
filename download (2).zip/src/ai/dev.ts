import { config } from 'dotenv';
config();

import '@/ai/flows/generate-daily-tasks.ts';
