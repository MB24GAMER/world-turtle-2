export type Element = 'fire' | 'water' | 'air' | 'earth' | 'space';

export type Animal = 'Dragon' | 'Whale' | 'Eagle' | 'Bear' | 'Fox';

export interface ElementInfo {
  name: Element;
  animal: Animal;
  image: string;
  imageHint: string;
}

export interface DailyTask {
  id: string;
  text: string;
  claimed: boolean;
  reward: number;
}

export interface ShopItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  imageHint: string;
}

export interface MiningRig {
  id: string;
  name: string;
  level: number;
  miningRate: number; // coins per second
  upgradeCost: number;
  progress: number;
  maxProgress: number;
  image: string;
  imageHint: string;
  lastClaimed: number; // timestamp
  accumulated: number;
}
