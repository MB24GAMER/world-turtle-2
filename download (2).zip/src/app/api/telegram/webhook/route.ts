
import {NextRequest, NextResponse} from 'next/server';

export async function POST(req: NextRequest) {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;

  if (!botToken) {
    console.error('TELEGRAM_BOT_TOKEN is not set.');
    return NextResponse.json({ status: 'error', message: 'Bot token not configured' }, { status: 500 });
  }

  try {
    const body = await req.json();
    console.log('Received Telegram update:', JSON.stringify(body, null, 2));

    // In a real application, you would process the update here.
    // For example, if a user starts the bot via a referral link,
    // you would extract the referral code from the message and
    // credit the referring user in your database.

    // For now, we'll just acknowledge receipt of the update.

    return NextResponse.json({ status: 'ok' });
  } catch (error) {
    console.error('Error processing Telegram update:', error);
    return NextResponse.json({ status: 'error', message: 'Invalid request' }, { status: 400 });
  }
}
