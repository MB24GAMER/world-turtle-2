'use client';

import Image from 'next/image';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { type Element, type ElementInfo } from '@/lib/types';
import { Button } from '@/components/ui/button';

const elements: ElementInfo[] = [
  { name: 'fire', animal: 'Dragon', image: '/dragon.png', imageHint: 'fantasy dragon' },
  { name: 'water', animal: 'Whale', image: '/whale.png', imageHint: 'majestic whale' },
  { name: 'air', animal: 'Eagle', image: '/eagle.png', imageHint: 'soaring eagle' },
  { name: 'earth', animal: 'Bear', image: '/bear.png', imageHint: 'powerful bear' },
  { name: 'space', animal: 'Fox', image: '/fox.png', imageHint: 'celestial fox' },
];

interface ElementSelectionProps {
  onSelect: (element: Element) => void;
}

export default function ElementSelection({ onSelect }: ElementSelectionProps) {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center mb-8"
      >
        <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-2 font-headline">Welcome to Elyra Mining</h1>
        <p className="text-lg text-muted-foreground">Choose your elemental guardian to begin your journey.</p>
      </motion.div>
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6 w-full max-w-7xl">
        {elements.map((element, index) => (
          <motion.div
            key={element.name}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className="overflow-hidden text-center group transition-all duration-300 hover:shadow-2xl hover:border-primary">
              <CardHeader className="p-0">
                <div className="relative h-48 w-full">
                  <Image
                    src={element.image}
                    alt={element.animal}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                    data-ai-hint={element.imageHint}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                </div>
                <CardTitle className="capitalize text-2xl font-bold absolute bottom-4 left-1/2 -translate-x-1/2 text-white z-10">
                  {element.name}
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 bg-card">
                <p className="text-muted-foreground mb-4 text-sm">Guardian: The {element.animal}</p>
                <Button 
                  onClick={() => onSelect(element.name)} 
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-bold"
                >
                  Select
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
