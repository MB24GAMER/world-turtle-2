'use client';

import { useState, useEffect, useCallback } from 'react';

// A custom hook to simulate referral tracking.
// In a real app, this would be handled by a backend.
const useReferralTracking = () => {
    useEffect(() => {
        if (typeof window === 'undefined') return;

        const urlParams = new URLSearchParams(window.location.search);
        const referralCode = urlParams.get('start');

        if (referralCode) {
            // This is a simplified simulation.
            // In a real application, you would make an API call to your backend
            // to verify the referral code and credit the referrer.

            // For now, we'll just increment a local storage value to simulate
            // a successful referral for demonstration purposes.
            const referredCountKey = 'invitedFriendsCount';
            const rewardsKey = 'rewardsEarned';
            
            try {
                // Check if this referral has been processed already to prevent double counting
                const lastProcessedCode = window.localStorage.getItem('lastProcessedReferral');
                if (lastProcessedCode !== referralCode) {
                    let currentCount = parseInt(window.localStorage.getItem(referredCountKey) || '0', 10);
                    let currentRewards = parseInt(window.localStorage.getItem(rewardsKey) || '0', 10);

                    currentCount++;
                    currentRewards += 250; // Example reward
                    
                    window.localStorage.setItem(referredCountKey, currentCount.toString());
                    window.localStorage.setItem(rewardsKey, currentRewards.toString());
                    window.localStorage.setItem('lastProcessedReferral', referralCode);
                    
                    // Dispatch a storage event to notify other components of the change
                    window.dispatchEvent(new Event('storage'));

                    // Clean the URL to avoid reprocessing on refresh
                    const newUrl = window.location.pathname;
                    window.history.replaceState({}, document.title, newUrl);
                }

            } catch (error) {
                console.warn('Could not process referral:', error);
            }
        }
    }, []);
};


function useLocalStorage<T>(key: string, initialValue: T): [T, (value: T | ((val: T) => T)) => void] {
  useReferralTracking();
  
  const readValue = useCallback((): T => {
    if (typeof window === 'undefined') {
      return initialValue;
    }
    try {
      const item = window.localStorage.getItem(key);
      return item ? (JSON.parse(item) as T) : initialValue;
    } catch (error) {
      console.warn(`Error reading localStorage key "${key}":`, error);
      return initialValue;
    }
  }, [initialValue, key]);

  const [storedValue, setStoredValue] = useState<T>(initialValue);

  const setValue = useCallback((value: T | ((val: T) => T)) => {
    if (typeof window == 'undefined') {
      console.warn(
        `Tried setting localStorage key “${key}” even though environment is not a client`
      );
    }

    try {
      const newValue = value instanceof Function ? value(storedValue) : value;
      window.localStorage.setItem(key, JSON.stringify(newValue));
      setStoredValue(newValue);
      window.dispatchEvent(new Event('storage')); // Notify other hooks
    } catch (error) {
      console.warn(`Error setting localStorage key "${key}":`, error);
    }
  }, [key, storedValue]);

  useEffect(() => {
    setStoredValue(readValue());
  }, [key, readValue]);

  useEffect(() => {
    const handleStorageChange = () => {
      setStoredValue(readValue());
    };

    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [readValue]);


  return [storedValue, setValue];
}

export default useLocalStorage;
