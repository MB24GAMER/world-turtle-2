'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import useLocalStorage from '@/hooks/use-local-storage';
import ElementSelection from '@/components/element-selection';
import { type Element } from '@/lib/types';
import { Loader2 } from 'lucide-react';

export default function WelcomePage() {
  const router = useRouter();
  const [selectedElement, setSelectedElement] = useLocalStorage<Element | null>('selectedElement', null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (selectedElement) {
      router.replace('/home');
    } else {
      setLoading(false);
    }
  }, [selectedElement, router]);

  const handleElementSelect = (element: Element) => {
    setSelectedElement(element);
  };

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  return <ElementSelection onSelect={handleElementSelect} />;
}
