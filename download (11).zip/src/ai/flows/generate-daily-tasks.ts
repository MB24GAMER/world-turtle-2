'use server';

/**
 * @fileOverview AI flow for generating personalized daily tasks for the user.
 *
 * - generateDailyTasks - A function that generates personalized daily tasks.
 * - GenerateDailyTasksInput - The input type for the generateDailyTasks function.
 * - GenerateDailyTasksOutput - The return type for the generateDailyTasks function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateDailyTasksInputSchema = z.object({
  userActivity: z
    .string()
    .describe(
      'A summary of the user activities, including completed tasks and progress in the game.'
    ),
  taskPreferences: z
    .string()
    .optional()
    .describe(
      'Optional user preferences for the daily tasks, e.g. preferred task types or difficulty.'
    ),
});
export type GenerateDailyTasksInput = z.infer<typeof GenerateDailyTasksInputSchema>;

const GenerateDailyTasksOutputSchema = z.object({
  tasks: z
    .array(z.string())
    .describe('A list of personalized daily tasks for the user.'),
});
export type GenerateDailyTasksOutput = z.infer<typeof GenerateDailyTasksOutputSchema>;

export async function generateDailyTasks(
  input: GenerateDailyTasksInput
): Promise<GenerateDailyTasksOutput> {
  return generateDailyTasksFlow(input);
}

const taskGeneratorPrompt = ai.definePrompt({
  name: 'taskGeneratorPrompt',
  input: {schema: GenerateDailyTasksInputSchema},
  output: {schema: GenerateDailyTasksOutputSchema},
  prompt: `You are an AI task generator for a mobile game called Elyra Mining. Your goal is to provide
  personalized and varied daily tasks for the user to keep them engaged and motivated.

  Here is a summary of the user's recent activity:
  {{userActivity}}

  Here are the user's task preferences, if any:
  {{taskPreferences}}

  Generate three daily tasks that are tailored to the user's activity and preferences.
  The tasks should be varied and encourage the user to explore different aspects of the game.
`,
});

const generateDailyTasksFlow = ai.defineFlow(
  {
    name: 'generateDailyTasksFlow',
    inputSchema: GenerateDailyTasksInputSchema,
    outputSchema: GenerateDailyTasksOutputSchema,
  },
  async input => {
    const {output} = await taskGeneratorPrompt(input);
    return output!;
  }
);
